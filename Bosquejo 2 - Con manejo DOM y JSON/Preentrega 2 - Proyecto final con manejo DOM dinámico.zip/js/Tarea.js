class Tarea{
  constructor (id, nombreTarea, tiempoTarea){
      this.id = id;
      this.nombreTarea = nombreTarea;
      this.tiempoTarea = tiempoTarea;
  }
}